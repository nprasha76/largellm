import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { ChaseAgent } from "@/agents/ChaseAgent/ChaseAgent";
import { CustomerAgent, type CustomerView } from "@/agents/CustomerAgent/CustomerAgent";
import { WFDefenderAgent } from "@/agents/WFDefenderAgent/WFDefenderAgent";
import { registerChaseWebhook, sendChaseFinal, startChaseAttack } from "@/agents/ChaseAgent/webhook";
import { registerCustomerWebhook, requestCounter, scoreOffer } from "@/agents/CustomerAgent/customerLogic";
import { handleCounterRequest, registerDefenderWebhook } from "@/agents/WFDefenderAgent/webhook";
import { parseAprFromText, type Offer } from "@/agents/ChaseAgent/chaseLogic";
import { agentBus, type AgentMessage } from "@/lib/agentBus";
import { Play, RotateCcw } from "lucide-react";
import customerData from "@/agents/WFDefenderAgent/customer.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "WF Stagecoach — Live Intercept" },
      { name: "description", content: "Live multi-agent retention demo: Chase vs Wells Fargo Stagecoach." },
    ],
  }),
  component: Page,
});

const DEFAULT_OPENING_TEXT = "13.9 % APR plus $200 cash back and no annual fee";
const FALLBACK_APR = 22.4;

type CustomerJson = {
  name: string;
  customer_agent_id: string;
  credit: { APR: string }[];
};

const customers = customerData as CustomerJson[];
const num = (s: string) => parseFloat(String(s).replace(/[^0-9.]/g, ""));

type LogEntry = { id: number; ts: string; from: string; to: string; type: string; summary: string };

function summarize(m: AgentMessage): string {
  const p = m.payload as Record<string, unknown>;
  if (m.type === "OPENING_OFFER" || m.type === "FINAL_OFFER") {
    return (p.offer as Offer).label;
  }
  if (m.type === "REQUEST_COUNTER") {
    const o = p.competingOffer as { apr: number };
    return `Competing offer received: ${o.apr}% APR. What is your best retention offer?`;
  }
  if (m.type === "COUNTER_OFFER") {
    return (p.text as string) ?? "Counter offer prepared.";
  }
  return JSON.stringify(p);
}

function Page() {
  const customerOptions = useMemo(() => customers.map((c) => ({ id: c.customer_agent_id, name: c.name })), []);

  const [selectedCustomerId, setSelectedCustomerId] = useState(customerOptions[0]?.id ?? "");
  const selectedCustomer = useMemo(
    () => customers.find((c) => c.customer_agent_id === selectedCustomerId),
    [selectedCustomerId],
  );
  const targetApr = useMemo(() => {
    if (!selectedCustomer) return 0;
    return Math.max(...selectedCustomer.credit.map((c) => num(c.APR)));
  }, [selectedCustomer]);

  const [openingText, setOpeningText] = useState(DEFAULT_OPENING_TEXT);
  const currentApr = useMemo(() => parseAprFromText(openingText) ?? FALLBACK_APR, [openingText]);

  const [productFit, setProductFit] = useState(71);
  const [switchingCost, setSwitchingCost] = useState(38);
  const [threshold, setThreshold] = useState(76);

  const [competingApr, setCompetingApr] = useState(13.9);
  const [opening, setOpening] = useState<Offer>();
  const [final, setFinal] = useState<Offer>();
  const [counterText, setCounterText] = useState<string>();
  const [customer, setCustomer] = useState<CustomerView>({});
  const [running, setRunning] = useState(false);
  const [retained, setRetained] = useState(52);
  const [outcome, setOutcome] = useState<string>();
  const [log, setLog] = useState<LogEntry[]>([]);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const logId = useRef(0);

  // Refs so the async webhook handlers see latest values without re-subscribing
  const competingAprRef = useRef(competingApr);
  competingAprRef.current = competingApr;
  const customerIdRef = useRef(selectedCustomerId);
  customerIdRef.current = selectedCustomerId;
  const openingTextRef = useRef(openingText);
  openingTextRef.current = openingText;
  const productFitRef = useRef(productFit);
  productFitRef.current = productFit;
  const switchingCostRef = useRef(switchingCost);
  switchingCostRef.current = switchingCost;
  const thresholdRef = useRef(threshold);
  thresholdRef.current = threshold;

  useEffect(() => {
    const offs = [
      registerCustomerWebhook(async (m) => {
        if (m.type === "OPENING_OFFER") {
          const offer = m.payload.offer as Offer;
          const cur = parseAprFromText(openingTextRef.current) ?? FALLBACK_APR;
          const scores = scoreOffer(
            offer.apr,
            cur,
            productFitRef.current,
            switchingCostRef.current,
            thresholdRef.current,
          );
          setCustomer((c) => ({ ...c, scores }));
          timers.current.push(
            setTimeout(() => {
              setCustomer((c) => ({ ...c, requestingCounter: true }));
              requestCounter(offer.apr, customerIdRef.current);
            }, 1100),
          );
        } else if (m.type === "COUNTER_OFFER") {
          const text = m.payload.text as string;
          const counter = m.payload.counter as { apr: number; fee: number; points: number };
          setCustomer((c) => ({ ...c, defenderText: text }));
          timers.current.push(
            setTimeout(() => {
              sendChaseFinal(competingAprRef.current, customerIdRef.current);
              const cur = parseAprFromText(openingTextRef.current) ?? FALLBACK_APR;
              const wfScores = scoreOffer(
                counter.apr,
                cur,
                productFitRef.current,
                switchingCostRef.current,
                thresholdRef.current,
              );
              const compScores = scoreOffer(
                competingAprRef.current,
                cur,
                productFitRef.current,
                switchingCostRef.current,
                thresholdRef.current,
              );
              const wfScore = wfScores.composite;
              const compScore = compScores.composite;
              setCustomer((c) => ({
                ...c,
                finalComparison: { wf: wfScore, competitor: compScore, delta: wfScore - compScore },
                finalScores: { wf: wfScore, competitor: compScore },
                recommendation:
                  wfScore >= compScore
                    ? "RECOMMEND STAY - Wells Fargo offer beats competitor."
                    : "RECOMMEND SWITCH - Competitor bank beats Wells Fargo offer.",
              }));
              setOutcome(wfScore >= compScore ? "Customer Retained" : "Customer Won");
              setRetained((r) => r + (wfScore >= compScore ? 1 : 0));
              setRunning(false);
            }, 1400),
          );
        } else if (m.type === "FINAL_OFFER") {
          setFinal(m.payload.offer as Offer);
        }
      }),
      registerDefenderWebhook(async (m) => {
        if (m.type === "REQUEST_COUNTER") {
          const competing = m.payload.competingOffer as { apr: number; fee: number; points: number };
          const customerAgentId = m.payload.customerAgentId as string;
          await handleCounterRequest(competing, customerAgentId);
        }
      }),
      registerChaseWebhook(() => {}),
      agentBus.onAny((m) => {
        setLog((l) => [
          ...l,
          {
            id: ++logId.current,
            ts: new Date().toLocaleTimeString([], { hour12: false }),
            from: m.from,
            to: m.to,
            type: m.type,
            summary: summarize(m),
          },
        ]);
      }),
    ];
    return () => offs.forEach((o) => o?.());
  }, []);

  const reset = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
    setOpening(undefined);
    setFinal(undefined);
    setCounterText(undefined);
    setCustomer({});
    setOutcome(undefined);
    setLog([]);
    setRunning(false);
  };

  const run = () => {
    reset();
    setRunning(true);
    timers.current.push(
      setTimeout(() => {
        const op = startChaseAttack(openingTextRef.current, customerIdRef.current);
        setOpening(op);
        // Sync competing APR from the (possibly edited) opening text
        const parsed = parseAprFromText(openingTextRef.current);
        if (parsed !== undefined) {
          setCompetingApr(parsed);
          competingAprRef.current = parsed;
        }
      }, 200),
    );
  };

  useEffect(() => {
    if (customer.defenderText) setCounterText(customer.defenderText);
  }, [customer.defenderText]);

  // Sync slider → opening offer text (replace the APR token)
  useEffect(() => {
    setOpeningText((prev) => {
      if (/(\d+(?:\.\d+)?)(\s*%)/.test(prev)) {
        return prev.replace(/(\d+(?:\.\d+)?)(\s*%)/, `${competingApr.toFixed(1)}$2`);
      }
      return `${competingApr.toFixed(1)} % APR ${prev}`;
    });
  }, [competingApr]);

  const compositeScore = customer.scores?.composite ?? 0;
  const customerName = selectedCustomer?.name ?? "";

  return (
    <div className="min-h-screen bg-[#f7f6f1] text-foreground font-sans">
      <header className="px-6 pt-5 pb-3 border-b border-border bg-[#f3f1ea]">
        <div className="text-[11px] tracking-[0.2em] font-semibold uppercase mb-3">
          Live Intercept — How Stagecoach Stops an Attack in Real Time
        </div>
        <div className="grid grid-cols-3 gap-6 text-[11px]">
          <div>
            <div className="font-bold uppercase tracking-wider">Objective: Steal the Customer</div>
            <div className="text-muted-foreground mt-0.5">
              Identifies financial pain points. Makes a provably better offer. Earns commission per successful switch.
            </div>
          </div>
          <div>
            <div className="font-bold uppercase tracking-wider">Objective: Best Outcome for Customer</div>
            <div className="text-muted-foreground mt-0.5">
              Loyal to no bank. Scores every offer on 3 dimensions. Triggers retention war. Recommends only if delta
              exceeds threshold.
            </div>
          </div>
          <div>
            <div className="font-bold uppercase tracking-wider">Objective: Retain the Customer</div>
            <div className="text-muted-foreground mt-0.5">
              Responds in under 2 seconds. Authorised retention budget per customer tier. Cannot be caught off guard.
            </div>
          </div>
        </div>

        <div className="mt-4 flex items-center gap-3 text-[10px] uppercase tracking-[0.2em]">
          <span className="font-bold">Switch Threshold</span>
          <div className="flex-1 h-[3px] bg-muted rounded-full relative">
            <div
              className="absolute inset-y-0 left-0 bg-emerald-500 transition-all"
              style={{ width: `${compositeScore}%` }}
            />
            <div
              className="absolute top-1/2 -translate-y-1/2 h-3 w-px bg-foreground"
              style={{ left: `${threshold}%` }}
            />
          </div>
          <span className="font-bold normal-case tracking-normal text-[11px]">
            Current offer score: <span className="text-base">{compositeScore}/100</span>
          </span>
          <span className="text-muted-foreground normal-case tracking-normal">
            {compositeScore < threshold ? "Below threshold — customer holds" : "Above threshold — switch likely"}
          </span>
        </div>
      </header>

      <main className="grid grid-cols-3 gap-0 px-6 py-8 min-h-[60vh]">
        <div className="pr-6 border-r border-border">
          <ChaseAgent
            opening={opening}
            final={final}
            customerOptions={customerOptions}
            selectedCustomerId={selectedCustomerId}
            onSelectCustomer={setSelectedCustomerId}
            targetApr={targetApr}
            openingText={openingText}
            onOpeningTextChange={setOpeningText}
            disabled={running}
          />
        </div>
        <div className="px-6 border-r border-border">
          <CustomerAgent
            v={customer}
            customerName={customerName}
            targetApr={targetApr}
            productFit={productFit}
            switchingCost={switchingCost}
            threshold={threshold}
            onProductFitChange={setProductFit}
            onSwitchingCostChange={setSwitchingCost}
            onThresholdChange={setThreshold}
            disabled={running}
          />
        </div>
        <div className="pl-6">
          <WFDefenderAgent counterText={counterText} />
        </div>
      </main>

      <section className="px-6 pb-6">
        <div className="border border-border rounded-sm bg-card">
          <div className="px-3 py-2 border-b border-border text-[10px] tracking-[0.2em] uppercase font-bold text-muted-foreground flex items-center justify-between">
            <span>Negotiation Log — Agent-to-Agent Messages</span>
            <span className="normal-case tracking-normal">{log.length} events</span>
          </div>
          <div className="max-h-56 overflow-y-auto divide-y divide-border font-mono text-[11px]">
            {log.length === 0 ? (
              <div className="px-3 py-3 text-muted-foreground italic">Awaiting first message…</div>
            ) : (
              log.map((e) => (
                <div key={e.id} className="px-3 py-1.5 flex gap-3">
                  <span className="text-muted-foreground tabular-nums">{e.ts}</span>
                  <span className={`uppercase font-bold ${tagColor(e.from)}`}>{e.from}</span>
                  <span className="text-muted-foreground">→</span>
                  <span className={`uppercase font-bold ${tagColor(e.to)}`}>{e.to}</span>
                  <span className="text-foreground/70 font-semibold">[{e.type}]</span>
                  <span className="text-foreground/90 truncate">{e.summary}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      {outcome && (
        <div className="px-6 py-3 border-t border-border flex items-center gap-4 text-[12px]">
          <span
            className={`px-2 py-1 rounded-sm text-white font-semibold uppercase tracking-wider text-[10px] ${outcome === "Customer Retained" ? "bg-emerald-700" : "bg-red-700"}`}
          >
            {outcome}
          </span>
          <span className="text-muted-foreground">{customer.recommendation}</span>
        </div>
      )}

      <footer className="px-6 py-4 border-t border-border flex flex-wrap items-center gap-4 bg-[#f7f6f1]">
        <Button
          onClick={run}
          disabled={running}
          className="bg-blue-900 hover:bg-blue-800 text-white rounded-sm h-9 px-4 text-[12px]"
        >
          <Play className="h-3 w-3" /> Run Defence
        </Button>
        <Button onClick={reset} variant="outline" className="rounded-sm h-9 px-4 text-[12px]">
          <RotateCcw className="h-3 w-3" /> Reset
        </Button>
        <div className="flex items-center gap-3 min-w-[280px]">
          <span className="text-[10px] uppercase tracking-[0.2em] font-bold whitespace-nowrap">Chase Final APR</span>
          <Slider
            value={[competingApr]}
            min={10}
            max={20}
            step={0.1}
            disabled={running}
            onValueChange={(v) => setCompetingApr(v[0])}
            className="w-40"
          />
          <span className="text-[12px] font-mono tabular-nums w-12">{competingApr.toFixed(1)}%</span>
        </div>
        {/*
        <span className="text-[12px] text-muted-foreground">
          Current APR derived: <span className="font-mono">{currentApr.toFixed(2)}%</span>
        </span>
        */}
        <span className="text-[12px] text-muted-foreground">{retained} customers retained today</span>

        <div className="flex-1" />
        <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
          Wells Fargo Stagecoach Intelligence — Internal Platform Demo · Confidential
        </span>
      </footer>
      <div className="h-1 bg-red-700" />
    </div>
  );
}

function tagColor(agent: string): string {
  if (agent === "chase") return "text-red-700";
  if (agent === "defender") return "text-emerald-700";
  if (agent === "customer") return "text-amber-700";
  return "text-foreground";
}
