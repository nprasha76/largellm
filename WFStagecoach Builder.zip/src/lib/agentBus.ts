// In-browser pub/sub simulating agent-to-agent webhook calls.
export type AgentMessage = {
  from: "chase" | "customer" | "defender";
  to: "chase" | "customer" | "defender";
  type: string;
  payload: Record<string, unknown>;
};

type Handler = (msg: AgentMessage) => void;
const handlers = new Map<string, Set<Handler>>();
const wildcardHandlers = new Set<Handler>();

export const agentBus = {
  on(agent: AgentMessage["to"], handler: Handler) {
    if (!handlers.has(agent)) handlers.set(agent, new Set());
    handlers.get(agent)!.add(handler);
    return () => handlers.get(agent)?.delete(handler);
  },
  onAny(handler: Handler) {
    wildcardHandlers.add(handler);
    return () => wildcardHandlers.delete(handler);
  },
  emit(msg: AgentMessage) {
    handlers.get(msg.to)?.forEach((h) => h(msg));
    wildcardHandlers.forEach((h) => h(msg));
  },
  clear() {
    handlers.clear();
    wildcardHandlers.clear();
  },
};

