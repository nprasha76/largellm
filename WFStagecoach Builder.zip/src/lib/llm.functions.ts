import { createServerFn } from "@tanstack/react-start";
import { generateText } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "./ai-gateway.server";

const Input = z.object({
  customer: z.record(z.string(), z.unknown()),
  targetCard: z.record(z.string(), z.unknown()),
  competingOffer: z.object({ apr: z.number(), fee: z.number(), points: z.number() }),
  computedCounter: z.object({
    apr: z.number(),
    fee: z.number(),
    points: z.number(),
    rationale: z.array(z.string()),
  }),
  rulesYaml: z.string(),
});

export const generateCounterOfferText = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => Input.parse(input))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");

    const gateway = createLovableAiGatewayProvider(key);
    const model = gateway("google/gemini-2.5-flash");

    const prompt = `You are the Wells Fargo Stagecoach Defender retention agent. A competing bank (Chase) is targeting our customer.

CUSTOMER PROFILE:
${JSON.stringify(data.customer, null, 2)}

TARGET CARD (most at risk):
${JSON.stringify(data.targetCard, null, 2)}

COMPETING OFFER FROM CHASE:
APR: ${data.competingOffer.apr}%, Annual Fee: $${data.competingOffer.fee}, Bonus Points: ${data.competingOffer.points}

BUSINESS RULES APPLIED:
${data.rulesYaml}

COMPUTED COUNTER (already passes all rules):
APR: ${data.computedCounter.apr.toFixed(2)}%, Fee: $${data.computedCounter.fee}, Points: ${data.computedCounter.points}
Rule rationale: ${data.computedCounter.rationale.join("; ")}

Write a single concise customer-facing counter-offer line (max 25 words) in the same style as: "APR reduced to 17% immediately, annual fee waived, 10,000 bonus points added to your account." Use the exact computed values above. No preamble.`;

    const { text } = await generateText({ model, prompt });
    return { text: text.trim() };
  });
