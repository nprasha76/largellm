import { cn } from "@/lib/utils";

export function StageCard({
  label,
  active,
  done,
  children,
  tone = "default",
}: {
  label: string;
  active?: boolean;
  done?: boolean;
  children: React.ReactNode;
  tone?: "default" | "chase" | "defender" | "customer";
}) {
  const dotColor =
    tone === "chase"
      ? "bg-red-600"
      : tone === "defender"
        ? "bg-emerald-600"
        : tone === "customer"
          ? "bg-amber-600"
          : "bg-foreground";
  return (
    <div className="relative flex flex-col items-center w-full">
      <span
        className={cn(
          "h-2 w-2 rounded-full mb-1.5 transition-all",
          dotColor,
          active && "ring-4 ring-offset-1 ring-current/20 animate-pulse",
          !active && !done && "opacity-30",
        )}
      />
      <div className="text-[10px] tracking-[0.18em] font-semibold text-muted-foreground uppercase mb-1.5">
        {label}
      </div>
      <div
        className={cn(
          "w-full border border-border bg-card text-card-foreground text-[12px] leading-snug px-3 py-2 rounded-sm shadow-sm transition-all",
          !active && !done && "opacity-40",
          active && "border-foreground/40",
        )}
      >
        {children}
      </div>
    </div>
  );
}

export function ScoreBar({ label, value, max = 100, tone = "default" }: { label: string; value: number; max?: number; tone?: "default" | "red" | "green" }) {
  const pct = Math.min(100, (value / max) * 100);
  const color = tone === "red" ? "bg-red-500" : tone === "green" ? "bg-emerald-500" : "bg-foreground";
  return (
    <div className="flex items-center gap-2 text-[11px]">
      <span className="w-24 text-muted-foreground">{label}</span>
      <div className="flex-1 h-[3px] bg-muted rounded-full overflow-hidden">
        <div className={cn("h-full transition-all duration-700", color)} style={{ width: `${pct}%` }} />
      </div>
      <span className="w-6 text-right tabular-nums">{Math.round(value)}</span>
    </div>
  );
}
