import { ScoreBar, StageCard } from "@/components/agent-ui";
import type { Scores } from "./customerLogic";

export type CustomerView = {
  scores?: Scores;
  requestingCounter?: boolean;
  defenderText?: string;
  finalComparison?: { wf: number; competitor: number; delta: number };
  finalScores?: { wf: number; competitor: number };
  recommendation?: string;
};

export type CustomerAgentProps = {
  v: CustomerView;
  customerName: string;
  targetApr: number;
  targetAprSource?: string;
  productFit: number;
  switchingCost: number;
  threshold: number;
  onProductFitChange: (n: number) => void;
  onSwitchingCostChange: (n: number) => void;
  onThresholdChange: (n: number) => void;
  disabled?: boolean;
  status?: React.ReactNode;
};

function NumberField({
  label,
  value,
  onChange,
  disabled,
}: {
  label: string;
  value: number;
  onChange: (n: number) => void;
  disabled?: boolean;
}) {
  return (
    <label className="flex items-center justify-between gap-2 text-[11px]">
      <span className="text-muted-foreground">{label}</span>
      <input
        type="number"
        min={0}
        max={100}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-20 border border-border bg-card rounded-sm px-2 py-1 text-[12px] font-mono tabular-nums focus:outline-none focus:border-foreground/40"
      />
    </label>
  );
}

export function CustomerAgent({
  v,
  customerName,
  targetApr,
  targetAprSource,
  productFit,
  switchingCost,
  threshold,
  onProductFitChange,
  onSwitchingCostChange,
  onThresholdChange,
  disabled,
  status,
}: CustomerAgentProps) {
  return (
    <div className="flex flex-col gap-5">
      <div>
        <div className="text-[10px] tracking-[0.18em] font-semibold text-muted-foreground uppercase">
          The Deciding Agent
        </div>
        <div className="text-base font-semibold mt-0.5 flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full bg-amber-600" />
          Personal Finance Agent — {customerName || "—"}
          {status}
        </div>
        <div className="text-[11px] text-muted-foreground mt-1">
          Target APR: <span className="font-mono tabular-nums">{targetApr.toFixed(2)}%</span>
          {targetAprSource ? <> · max from <span className="italic">{targetAprSource}</span></> : null}
        </div>
      </div>

      <div className="border border-border bg-card rounded-sm p-3 space-y-2">
        <div className="text-[10px] tracking-[0.18em] font-semibold text-muted-foreground uppercase mb-1">
          Scoring Inputs
        </div>
        <div className="flex items-center justify-between gap-2 text-[11px]">
          <span className="text-muted-foreground">Financial gain (auto)</span>
          <span className="w-20 text-right font-mono tabular-nums text-[12px]">
            {v.scores ? v.scores.financialGain : "—"}
          </span>
        </div>
        <NumberField label="Product fit" value={productFit} onChange={onProductFitChange} disabled={disabled} />
        <NumberField
          label="Switching cost"
          value={switchingCost}
          onChange={onSwitchingCostChange}
          disabled={disabled}
        />
        <NumberField label="Threshold" value={threshold} onChange={onThresholdChange} disabled={disabled} />
      </div>

      <StageCard label="Evaluating Offer" tone="customer" active={!!v.scores} done={!!v.scores}>
        {v.scores
          ? `Financial gain ${v.scores.financialGain}/100, Product fit ${v.scores.productFit}/100, Switching cost ${v.scores.switchingCost}/100, composite ${v.scores.composite}/100, threshold ${v.scores.threshold}.`
          : "Waiting for competing offer…"}
      </StageCard>

      <StageCard label="Offer Evaluation" tone="customer" active={!!v.scores} done={!!v.scores}>
        {v.scores ? (
          <div className="space-y-1.5 py-1">
            <ScoreBar label="Financial gain" value={v.scores.financialGain} />
            <ScoreBar label="Product fit" value={v.scores.productFit} />
            <ScoreBar label="Ease of switch" value={v.scores.switchingCost} tone="red" />
          </div>
        ) : (
          "—"
        )}
      </StageCard>

      <StageCard label="Requesting Counter" tone="customer" active={v.requestingCounter} done={!!v.defenderText}>
        Sending offer received from competing bank for negotiation…
      </StageCard>

      <StageCard
        label="Can WF as Defending Bank Beat This?"
        tone="customer"
        active={!!v.defenderText}
        done={!!v.finalComparison}
      >
        {v.defenderText ?? "Awaiting Wells Fargo response…"}
      </StageCard>

      <StageCard label="Final Comparison" tone="customer" active={!!v.finalComparison} done={!!v.finalComparison}>
        {v.finalComparison
          ? `WF as Defending bank final ${v.finalComparison.wf}/100, Competing bank ${v.finalComparison.competitor}/100, delta ${v.finalComparison.delta > 0 ? "+" : ""}${v.finalComparison.delta}.`
          : "—"}
      </StageCard>

      <StageCard label="Offer Evaluation" tone="customer" active={!!v.finalScores} done={!!v.finalScores}>
        {v.finalScores ? (
          <div className="space-y-1.5 py-1">
            <ScoreBar label="WF offer score" value={v.finalScores.wf} tone="green" />
            <ScoreBar label="Competitor score" value={v.finalScores.competitor} />
          </div>
        ) : (
          "—"
        )}
      </StageCard>

      <StageCard label="Recommendation" tone="customer" active={!!v.recommendation} done={!!v.recommendation}>
        {v.recommendation ?? "—"}
      </StageCard>
    </div>
  );
}
