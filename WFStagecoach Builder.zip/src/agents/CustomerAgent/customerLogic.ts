import { agentBus, type AgentMessage } from "@/lib/agentBus";

export type Scores = {
  financialGain: number;
  productFit: number;
  switchingCost: number;
  composite: number;
  threshold: number;
};

export const scoreOffer = (
  apr: number,
  currentApr: number,
  productFit = 71,
  switchingCost = 38,
  threshold = 76,
): Scores => {
  const financialGain = Math.max(
    0,
    Math.min(100, Math.round(((currentApr - apr) / currentApr) * 350 + 60)),
  );
  const composite = Math.round(financialGain * 0.5 + productFit * 0.3 + switchingCost * 0.2);
  return { financialGain, productFit, switchingCost, composite, threshold };
};

export const requestCounter = (competingApr: number, customerAgentId: string) => {
  agentBus.emit({
    from: "customer",
    to: "defender",
    type: "REQUEST_COUNTER",
    payload: {
      competingOffer: { apr: competingApr, fee: 0, points: 0 },
      customerAgentId,
    },
  });
};

export const registerCustomerWebhook = (onMessage: (m: AgentMessage) => void) =>
  agentBus.on("customer", onMessage);
