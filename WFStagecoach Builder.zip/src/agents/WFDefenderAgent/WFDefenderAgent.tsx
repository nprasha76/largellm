import { StageCard } from "@/components/agent-ui";
import wfLogo from "@/assets/wells-fargo-logo.png";

export function WFDefenderAgent({
  counterText,
  status,
}: {
  counterText?: string;
  status?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-start gap-3">
        <img
          src={wfLogo}
          alt="Wells Fargo"
          className="h-10 w-10 rounded-sm shrink-0"
        />
        <div>
          <div className="text-[10px] tracking-[0.18em] font-semibold text-muted-foreground uppercase">
            Wells Fargo Defence
          </div>
          <div className="text-base font-semibold mt-0.5 flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-600" />
            Stagecoach Rapid Response
            {status}
          </div>
        </div>
      </div>
      <StageCard label="Counter-Offer (under 2 sec)" tone="defender" active={!!counterText} done={!!counterText}>
        {counterText ?? "Awaiting attack signal…"}
      </StageCard>
    </div>
  );
}
