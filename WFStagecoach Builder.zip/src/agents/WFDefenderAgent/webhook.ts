import { agentBus, type AgentMessage } from "@/lib/agentBus";
import rulesYml from "./defender_rules.yml?raw";
import {
  computeCounterOffer,
  getCustomer,
  pickTargetCard,
  type CompetingOffer,
  type CounterOffer,
} from "./defenderLogic";
import { generateCounterOfferText } from "@/lib/llm.functions";

export const handleCounterRequest = async (
  competing: CompetingOffer,
  customerAgentId: string,
): Promise<{ counter: CounterOffer; text: string }> => {
  const customer = getCustomer(customerAgentId);
  if (!customer) throw new Error("Customer not found");
  const card = pickTargetCard(customer);
  const counter = computeCounterOffer(card, competing);

  let text = `APR reduced to ${counter.apr.toFixed(2)}%, ${counter.fee === 0 ? "annual fee waived" : `fee $${counter.fee}`}, ${counter.points.toLocaleString()} bonus points added to your account.`;
  try {
    const res = await generateCounterOfferText({
      data: {
        customer: customer as unknown as Record<string, unknown>,
        targetCard: card as unknown as Record<string, unknown>,
        competingOffer: competing,
        computedCounter: counter,
        rulesYaml: rulesYml,
      },
    });
    if (res?.text) text = res.text;
  } catch (e) {
    console.warn("LLM fallback used:", e);
  }

  agentBus.emit({
    from: "defender",
    to: "customer",
    type: "COUNTER_OFFER",
    payload: { counter, text },
  });

  return { counter, text };
};

export const registerDefenderWebhook = (onMessage: (m: AgentMessage) => void) =>
  agentBus.on("defender", onMessage);
