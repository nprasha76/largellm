import customerData from "./customer.json";

export type CompetingOffer = {
  apr: number;
  fee: number;
  points: number;
};

export type CounterOffer = {
  apr: number;
  fee: number;
  points: number;
  rationale: string[];
};

export type CustomerCard = {
  product: string;
  APR: string;
  fee: string;
  points: string;
  credit_limit: string;
  avg_monthly_spend: string;
};

export type Customer = {
  name: string;
  customer_agent_id: string;
  email: string;
  state: string;
  customer_since: number;
  products: number;
  dda_balance: number;
  credit: CustomerCard[];
};

const num = (s: string) => parseFloat(String(s).replace(/[^0-9.]/g, ""));

export const getCustomer = (agentId: string): Customer | undefined =>
  (customerData as Customer[]).find((c) => c.customer_agent_id === agentId);

export const pickTargetCard = (customer: Customer): CustomerCard => {
  // Pick card with highest APR (most at risk of switching)
  return [...customer.credit].sort((a, b) => num(b.APR) - num(a.APR))[0];
};

export const computeCounterOffer = (card: CustomerCard, competing: CompetingOffer): CounterOffer => {
  const currentApr = num(card.APR);
  const currentFee = num(card.fee);
  const currentPoints = num(card.points);
  const monthlySpend = num(card.avg_monthly_spend);

  const rationale: string[] = [];
  let newApr = currentApr;
  let newFee = currentFee;
  let newPoints = currentPoints;

  // APR rule: only if > 15%, find max rate where 13 < rate < competingApr, reduce by basis points
  if (currentApr > 15) {
    // Max rate strictly less than competing offer, above 13%, decreased by 2 basis point
    const candidate = Math.max(13.01, competing.apr - 0.02);
    newApr = Math.min(candidate, currentApr);
    rationale.push(
      `APR reduced from ${currentApr}% to ${newApr.toFixed(2)}% (rule 1: APR>16%, undercut competing ${competing.apr}% by 1bp)`,
    );
  }

  // Points rule: +100 if current < 4000
  if (currentPoints < 4000) {
    newPoints = currentPoints + 100;
    rationale.push(`Points increased by 100 (rule 2: current ${currentPoints} < 4000)`);
  }

  // Fee rule: waive if avg_monthly_spend > 1000
  if (monthlySpend > 1000) {
    newFee = 0;
    rationale.push(`Annual fee waived (rule 3: avg monthly spend $${monthlySpend} > $1000)`);
  }

  return { apr: newApr, fee: newFee, points: newPoints, rationale };
};
