export type Offer = {
  apr: number;
  fee: number;
  points: number;
  cashBack: number;
  label: string;
};

// Parse first percentage value from a free-form text (e.g. "13.9 % APR ..." -> 13.9)
export const parseAprFromText = (text: string): number | undefined => {
  const m = text.match(/(\d+(?:\.\d+)?)\s*%/);
  return m ? parseFloat(m[1]) : undefined;
};

export const openingOffer = (openingText: string, fallbackApr = 13.9): Offer => {
  const apr = parseAprFromText(openingText) ?? fallbackApr;
  return {
    apr,
    fee: 0,
    points: 0,
    cashBack: 0,
    label: openingText,
  };
};

export const finalOffer = (competingApr: number): Offer => ({
  apr: competingApr,
  fee: 0,
  points: 0,
  cashBack: 0,
  label: `${competingApr}% final APR — best and final offer.`,
});
