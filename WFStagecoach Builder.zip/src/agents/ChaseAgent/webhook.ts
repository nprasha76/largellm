import { agentBus, type AgentMessage } from "@/lib/agentBus";
import { openingOffer, finalOffer } from "./chaseLogic";

export const startChaseAttack = (openingText: string, customerAgentId: string) => {
  const op = openingOffer(openingText);
  agentBus.emit({
    from: "chase",
    to: "customer",
    type: "OPENING_OFFER",
    payload: { offer: op, customerAgentId },
  });
  return op;
};

export const sendChaseFinal = (competingApr: number, customerAgentId: string) => {
  const f = finalOffer(competingApr);
  agentBus.emit({
    from: "chase",
    to: "customer",
    type: "FINAL_OFFER",
    payload: { offer: f, customerAgentId },
  });
  return f;
};

export const registerChaseWebhook = (onMessage: (m: AgentMessage) => void) =>
  agentBus.on("chase", onMessage);
