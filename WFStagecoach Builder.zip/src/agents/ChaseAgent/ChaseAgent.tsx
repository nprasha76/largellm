import { StageCard } from "@/components/agent-ui";
import type { Offer } from "./chaseLogic";

export type ChaseAgentProps = {
  opening?: Offer;
  final?: Offer;
  customerOptions: { id: string; name: string }[];
  selectedCustomerId: string;
  onSelectCustomer: (id: string) => void;
  targetApr: number;
  openingText: string;
  onOpeningTextChange: (s: string) => void;
  disabled?: boolean;
  status?: React.ReactNode;
};

export function ChaseAgent({
  opening,
  final,
  customerOptions,
  selectedCustomerId,
  onSelectCustomer,
  targetApr,
  openingText,
  onOpeningTextChange,
  disabled,
  status,
}: ChaseAgentProps) {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <div className="text-[10px] tracking-[0.18em] font-semibold text-muted-foreground uppercase">
          Competitor (Chase)
        </div>
        <div className="text-base font-semibold mt-0.5 flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full bg-red-600" />
          Chase AI Hunter Agent
          {status}
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <label className="text-[10px] tracking-[0.18em] font-semibold text-muted-foreground uppercase">
          Customer Agent ID
        </label>
        <select
          value={selectedCustomerId}
          onChange={(e) => onSelectCustomer(e.target.value)}
          disabled={disabled}
          className="border border-border bg-card text-[12px] rounded-sm px-2 py-1.5 focus:outline-none focus:border-foreground/40"
        >
          {customerOptions.map((c) => (
            <option key={c.id} value={c.id}>
              {c.id}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1.5">
        <label className="text-[10px] tracking-[0.18em] font-semibold text-muted-foreground uppercase">
          Target APR (read-only)
        </label>
        <input
          type="text"
          readOnly
          value={`${targetApr.toFixed(2)} %`}
          className="border border-border bg-muted/40 text-[12px] rounded-sm px-2 py-1.5 font-mono tabular-nums"
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <label className="text-[10px] tracking-[0.18em] font-semibold text-muted-foreground uppercase">
          Opening Offer (editable)
        </label>
        <textarea
          value={openingText}
          onChange={(e) => onOpeningTextChange(e.target.value)}
          disabled={disabled}
          rows={3}
          className="border border-border bg-card text-[12px] rounded-sm px-2 py-1.5 focus:outline-none focus:border-foreground/40 resize-none"
        />
      </div>

      <StageCard label="Opening Offer Sent" tone="chase" active={!!opening} done={!!opening}>
        {opening?.label ?? "Click Run Defence to send…"}
      </StageCard>
      <StageCard label="Final Offer" tone="chase" active={!!final} done={!!final}>
        {final?.label ?? "Waiting…"}
      </StageCard>
    </div>
  );
}
