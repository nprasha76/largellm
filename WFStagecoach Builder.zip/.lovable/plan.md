# WFStagecoach — 3-Agent Retention Demo

A single-page demo app showing three AI agents negotiating in real time: **ChaseAgent** (attacker) → **CustomerAgent** (Sarah K., deciding) → **WFDefenderAgent** (retention). Layout mirrors the screenshot: three vertical columns + a bottom intelligence panel.

## Folder structure

Each agent gets its own folder with all its files (UI, logic, webhook, data):

```
src/agents/
  ChaseAgent/
    ChaseAgent.tsx          # Left column UI
    chaseLogic.ts           # Generates opening + final offer
    webhook.ts              # Receives/sends messages
  CustomerAgent/
    CustomerAgent.tsx       # Middle column UI (Sarah K.)
    customerLogic.ts        # Scores offers on 12 dimensions, routes
    webhook.ts
  WFDefenderAgent/
    WFDefenderAgent.tsx     # Right column UI
    defenderLogic.ts        # Applies rules + calls LLM
    webhook.ts
    customer.json           # Customer data (John Kennedy + 3 cards)
    defender_rules.yml      # Business rules
src/lib/
  agentBus.ts               # In-browser pub/sub simulating webhooks
  llm.functions.ts          # createServerFn → AI SDK + Lovable AI Gateway
src/routes/index.tsx        # Three-column layout + bottom intel panel
```

Webhooks are simulated client-side via `agentBus` (event emitter) so all three agents run in the browser and exchange messages with visible UI updates. This matches the "agent-to-agent" intent without requiring three deployed servers.

## UI layout (matches screenshot)

- **Top strip**: title "LIVE INTERCEPT — HOW STAGECOACH STOPS AN ATTACK IN REAL TIME", three objective headers, switch-threshold bar with score 76/100.
- **Three columns**, each a vertical timeline of stage cards:
  - **Chase (left)**: Opening Offer → Final Offer
  - **Customer/Sarah (middle)**: Evaluating Offer → Offer Evaluation (3 bars) → Requesting Counter → Can Defending Bank Beat This? → Final Comparison → Offer Evaluation (WF vs Competitor) → Recommendation
  - **WFDefender (right)**: Counter-Offer (under 2s)
- **Bottom intelligence panel**: WHAT WAS DETECTED, HOW WE RESPONDED, WHY CUSTOMERS STAY, WHAT WE LEARNED, COUNTER MOVE.
- **Footer controls**: ▶ Run Defence, Reset, "52 customers retained today".

## Counter-offer logic (WFDefender)

Given competing offer `{APR, fee, points}` and customer card chosen by best fit:

1. **APR rule** — if customer APR > 16%: new APR = max rate where `13% < newAPR < competingAPR`, decreased in basis points (0.01%). Demo: `competingAPR − 1bp` floored to 13.01%.
2. **Points rule** — if current points < 4000: points += 100.
3. **Fee rule** — if avg_monthly_spend > 1000 USD: waive fee.
4. Apply all three.

Rules computed locally produce a deterministic counter offer. Customer context (from `WFDefenderAgent/customer.json`) + parsed rules (from `WFDefenderAgent/defender_rules.yml`) + competing offer + computed counter are passed to the **LLM (Lovable AI Gateway, `google/gemini-2.5-flash`)** to produce the human-readable counter-offer message rendered in the WFDefender card and sent to CustomerAgent.

## Run flow (▶ Run Defence)

1. ChaseAgent emits opening offer (13.9% APR, $200 cash back, no fee) → CustomerAgent.
2. CustomerAgent scores 3 dimensions, shows financial-gain/product-fit/ease-of-switch bars, emits "requesting counter" → WFDefenderAgent.
3. WFDefenderAgent loads customer.json (matches by `customer_agent_id`), applies defender_rules.yml, calls LLM, returns counter offer; renders right column and feeds Customer's "Can defending bank beat this?" → "Final comparison" → "Recommendation".
4. Chase emits final offer; Customer recomputes final WF vs Competitor scores; footer flips to "Customer Won / RECOMMEND SWITCH" or "Customer Retained" based on delta.

## Technical notes

- **Stack**: TanStack Start (existing), Tailwind v4 tokens in `src/styles.css`.
- **LLM**: server function `generateCounterOffer` using AI SDK + Lovable AI Gateway. Prompt includes customer JSON, parsed YAML rules, competing offer, and computed numeric counter; LLM returns short justification + bullet summary.
- **Styling**: light "paper" background, thin column dividers, small uppercase stage labels, horizontal score bars — matches the demo's clinical console aesthetic.
- **Animation**: stage cards fade/slide in sequentially as the bus delivers messages.

## Prerequisite

Enabling **Lovable Cloud / Lovable AI Gateway** is required for the LLM step (free Gemini models during preview).
